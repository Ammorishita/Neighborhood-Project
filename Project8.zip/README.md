Udacity Neighborhod Map Project 8

Single page application that displays 5 restaurant locations.

Run the application:

1.Open index.html in a browswer.
2.Click markers to display related information.
3.Search specific locations in the filter search box.

Notes

1. Makes use of knockout.js, oauth-signature.min, and jQuery libraries.
2. Uses wikipedia, yelp, openweathermap and google maps api.